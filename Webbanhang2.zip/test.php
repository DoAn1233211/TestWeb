<?php
session_destroy();

